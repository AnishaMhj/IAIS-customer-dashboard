import {
  img,
  img2,
  img3,
  img4,
  img5,
  sc1,
  sc2,
  sc3,
  sc4,
  sc5,
} from "../../assets/index";

export const tileData = [
  {
    img: img2,
    title: "Image",
    author: "author",
    featured: "false",
  },
  {
    img: img3,
    title: "Image",
    author: "author",
    featured: "false",
  },
  {
    img: img4,
    title: "Image",
    author: "author",
    featured: "false",
  },
  {
    img: img5,
    title: "Image",
    author: "author",
    featured: "false",
  },
  // {
  //   img: img,
  //   title: "Image",
  //   author: "author",
  //   featured: "true",
  // },
];

export const tileData2 = [
  {
    img: sc1,
    title: "Image",
    author: "author",
    featured: "false",
  },
  {
    img: sc2,
    title: "Image",
    author: "author",
    featured: "false",
  },
  // {
  //   img: sc3,
  //   title: "Image",
  //   author: "author",
  //   featured: "true",
  // },
  {
    img: sc4,
    title: "Image",
    author: "author",
    featured: "false",
  },
  {
    img: sc5,
    title: "Image",
    author: "author",
    featured: "false",
  },
];
