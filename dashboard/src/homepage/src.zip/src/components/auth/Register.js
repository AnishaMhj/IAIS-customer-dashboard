import React from 'react'

export const Register = () => {
  return <div></div>
}
